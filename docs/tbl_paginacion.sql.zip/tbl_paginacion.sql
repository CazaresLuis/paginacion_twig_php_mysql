-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 19-10-2013 a las 07:19:50
-- Versión del servidor: 5.5.25
-- Versión de PHP: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `tutosWeb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_paginacion`
--

CREATE TABLE `tbl_paginacion` (
  `id_registro` mediumint(9) DEFAULT NULL,
  `rg_nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rg_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rg_status` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tbl_paginacion`
--

INSERT INTO `tbl_paginacion` (`id_registro`, `rg_nombre`, `rg_email`, `rg_status`) VALUES
(1, 'Price Goodman', 'Donec.vitae@Nam.com', 3),
(2, 'Emery Ramos', 'Nulla@atsemmolestie.org', 3),
(3, 'Hedley Ingram', 'amet.dapibus.id@elit.org', 2),
(4, 'Jin Galloway', 'feugiat.Lorem.ipsum@nisinibh.co.uk', 2),
(5, 'Trevor Bean', 'metus.facilisis@idmagna.net', 1),
(6, 'Lionel Combs', 'convallis.erat@pede.org', 2),
(7, 'Wylie Wilkerson', 'diam@dolorFuscemi.com', 2),
(8, 'Keaton Melendez', 'Duis.cursus@mollisvitaeposuere.com', 1),
(9, 'Patrick Morrison', 'arcu.imperdiet.ullamcorper@nisi.com', 1),
(10, 'Dieter Mccullough', 'odio.auctor.vitae@sitamet.ca', 1),
(11, 'Channing Wood', 'ipsum.primis.in@arcu.ca', 1),
(12, 'Jonas Barrera', 'nunc.sit.amet@Aliquam.edu', 3),
(13, 'Moses Kline', 'neque.Morbi.quis@etpedeNunc.net', 2),
(14, 'Kenyon Fuller', 'arcu.Vestibulum@accumsaninterdum.org', 3),
(15, 'Nigel Henson', 'natoque@CuraeDonec.net', 3),
(16, 'Nolan Marks', 'lobortis.quis@Donecdignissim.net', 3),
(17, 'Tanner Horn', 'enim.nec@Nulladignissim.co.uk', 1),
(18, 'Cooper Kirk', 'tempor.est@utdolor.org', 1),
(19, 'Seth Callahan', 'Lorem.ipsum.dolor@est.ca', 3),
(20, 'Clinton Moore', 'Nulla.interdum.Curabitur@nequevenenatislacus.edu', 2),
(21, 'Hammett Mullins', 'eget@Lorem.edu', 3),
(22, 'Denton Mckinney', 'nunc.sit@euplacerat.co.uk', 3),
(23, 'Dalton Hammond', 'penatibus.et@magna.org', 3),
(24, 'Quamar Molina', 'Fusce@nec.ca', 1),
(25, 'Silas Bray', 'fringilla@lobortisrisus.net', 1),
(26, 'Griffith Shepard', 'sed.dictum.eleifend@anuncIn.com', 1),
(27, 'Joel Horton', 'accumsan.convallis.ante@leoelementumsem.org', 1),
(28, 'Jin Talley', 'magna@liberoMorbi.net', 2),
(29, 'Wylie Brown', 'enim@metus.com', 3),
(30, 'Hop Obrien', 'non.quam@elitpedemalesuada.edu', 2),
(31, 'Laith Trujillo', 'dolor.elit.pellentesque@vitaepurusgravida.ca', 2),
(32, 'Levi Pope', 'augue.ac.ipsum@pedeblanditcongue.ca', 1),
(33, 'Porter Becker', 'Donec.at@placeratorci.net', 2),
(34, 'Benedict Sellers', 'massa.lobortis@Phasellusdolorelit.edu', 1),
(35, 'Bernard Craig', 'lectus.ante@ametloremsemper.com', 2),
(36, 'Axel Pena', 'nunc.id.enim@Pellentesqueultriciesdignissim.com', 2),
(37, 'Alexander Norton', 'a@vitaealiquet.com', 1),
(38, 'Nehru Holloway', 'dignissim.pharetra.Nam@vulputate.co.uk', 1),
(39, 'Lawrence Blair', 'est@urnajusto.com', 3),
(40, 'Kyle Holmes', 'id.magna@loremeget.edu', 2),
(41, 'Brendan Woodward', 'dolor@faucibusut.edu', 2),
(42, 'Holmes Lewis', 'urna@Crasconvallisconvallis.org', 2),
(43, 'Lucas Jimenez', 'nibh@magnaDuisdignissim.net', 2),
(44, 'Micah Reilly', 'morbi@pellentesqueeget.ca', 3),
(45, 'August Parker', 'amet.risus.Donec@non.ca', 2),
(46, 'James Roth', 'leo.Vivamus@miAliquamgravida.ca', 1),
(47, 'Kevin Buck', 'Donec@Seddictum.co.uk', 1),
(48, 'George Spears', 'dui@tempusnon.co.uk', 1),
(49, 'Geoffrey Kennedy', 'justo@Nullaeuneque.co.uk', 1),
(50, 'Dieter Mcfarland', 'dolor.Donec.fringilla@estac.com', 3),
(51, 'Jermaine Phelps', 'Suspendisse.tristique@asollicitudinorci.ca', 1),
(52, 'Aladdin Booth', 'tempor@Duisgravida.co.uk', 3),
(53, 'Randall Wilder', 'vitae.aliquet@Quisqueporttitoreros.co.uk', 1),
(54, 'Charles Moore', 'aptent@lobortistellus.com', 3),
(55, 'Quinlan Horn', 'nisi.sem@quam.com', 2),
(56, 'Hyatt English', 'aliquet.sem@porttitorscelerisque.co.uk', 2),
(57, 'Keefe Pena', 'ut.pellentesque@faucibusleo.org', 2),
(58, 'Jakeem Collins', 'risus.Nulla@Nam.net', 2),
(59, 'Arsenio Martinez', 'Praesent.luctus@tincidunt.edu', 1),
(60, 'Finn Torres', 'amet@nisiAeneaneget.com', 2),
(61, 'Rigel Wallace', 'justo.nec.ante@necenim.com', 1),
(62, 'Barrett Bond', 'vitae@Morbiaccumsanlaoreet.ca', 1),
(63, 'Jerome Madden', 'pharetra.Quisque.ac@eueuismodac.org', 3),
(64, 'Lucas Mcclure', 'tortor.nibh@congueIn.co.uk', 1),
(65, 'Camden George', 'Suspendisse.aliquet.sem@PhasellusornareFusce.com', 2),
(66, 'Gannon Britt', 'et.libero@lectus.com', 1),
(67, 'Kenneth Fleming', 'ultrices.iaculis@dolor.co.uk', 2),
(68, 'Julian Castro', 'ipsum@hendrerit.com', 3),
(69, 'Gage Guzman', 'ultrices.posuere.cubilia@ategestas.net', 2),
(70, 'Theodore Mccarty', 'nulla.Donec@tellussemmollis.co.uk', 1),
(71, 'Denton Mcgowan', 'euismod@sitamet.ca', 1),
(72, 'Raymond Russell', 'diam.Duis@disparturient.co.uk', 1),
(73, 'Hector Fitzpatrick', 'auctor.Mauris@aliquetmagnaa.net', 1),
(74, 'Erasmus Francis', 'magna.Sed.eu@ipsum.com', 3),
(75, 'Arsenio Marquez', 'ac.feugiat.non@nec.edu', 2),
(76, 'Mason Best', 'Phasellus.elit.pede@Aliquam.net', 1),
(77, 'Davis Mathis', 'dis@Morbi.net', 2),
(78, 'Carter Elliott', 'rutrum.lorem.ac@facilisis.com', 2),
(79, 'Edan Wall', 'lorem.ipsum@tempusmauriserat.edu', 3),
(80, 'Colt Reid', 'Quisque.fringilla@sagittisDuisgravida.ca', 2),
(81, 'Eagan Newman', 'nisi@acmetusvitae.co.uk', 1),
(82, 'Walter Valenzuela', 'iaculis.quis@velitAliquam.com', 3),
(83, 'Carl Vargas', 'velit@diameudolor.org', 3),
(84, 'Richard Hutchinson', 'tellus.imperdiet@facilisis.org', 1),
(85, 'Drew Valenzuela', 'turpis.nec.mauris@quis.ca', 2),
(86, 'Gannon Ratliff', 'erat@convallisest.ca', 2),
(87, 'Malcolm Macias', 'scelerisque@congueInscelerisque.edu', 1),
(88, 'Asher Pollard', 'In@justosit.edu', 2),
(89, 'Herrod Weeks', 'Pellentesque.tincidunt.tempus@ultriciesligula.net', 3),
(90, 'Roth Stafford', 'orci.Phasellus@sempercursus.ca', 3),
(91, 'Hayes Cain', 'ipsum.ac.mi@lacusvarius.co.uk', 1),
(92, 'Quentin Hurst', 'accumsan@scelerisquemollisPhasellus.org', 3),
(93, 'Russell Glass', 'aliquam@nibhPhasellusnulla.net', 2),
(94, 'Zephania Travis', 'placerat.augue@vitaeodio.edu', 1),
(95, 'Chancellor Steele', 'faucibus@orciPhasellusdapibus.co.uk', 1),
(96, 'Cullen Santiago', 'dictum@venenatisamagna.net', 3),
(97, 'Alden Craig', 'nisl.sem.consequat@musDonecdignissim.net', 2),
(98, 'Oren Rivas', 'faucibus.ut.nulla@Donecelementum.net', 2),
(99, 'Mason Blanchard', 'ultricies.ligula.Nullam@eratnonummyultricies.net', 1),
(100, 'Jakeem Chambers', 'Nullam.suscipit.est@nasceturridiculusmus.com', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
